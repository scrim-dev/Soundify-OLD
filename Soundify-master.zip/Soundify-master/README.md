# Soundify
One click away from your favorite track!


[![Download zip](https://custom-icon-badges.demolab.com/badge/-Download-purple?style=for-the-badge&logo=download&logoColor=white "Download")](https://github.com/scrim-dev/Soundify/releases)
<p align="center">
  <img src="https://cdn.discordapp.com/attachments/1003092019087949919/1220267877244862484/DropshadowSoundifyLogo.png?ex=6620c705&is=660e5205&hm=6ee11b3bedf032d08ec7c5a29c6acc23bbba61f33612b5ea397e2e63627485e7&" alt="Soundify Logo" width="320">
</p>

## What is Soundify?
Soundify is a one of a kind versatile music app designed to enhance the listening experience by seamlessly integrating streaming platforms such as SoundCloud and Spotify. With Soundify, users can access a vast library of music from both platforms, providing a diverse range of genres and artists to explore, also making it easier to listen to your playlists on either platforms.

In addition to its streaming capabilities, Soundify also offers integration with VRChat OSC (VRCOSC), enabling users to enhance their virtual reality experiences with synchronized music playback. By connecting Soundify to VRChat, users can create immersive environments where music seamlessly accompanies their virtual interactions and adventures.

Overall, Soundify offers a comprehensive solution for music enthusiasts, combining the convenience of multi-platform streaming with intuitive media controls and immersive VR integration. Whether it's discovering new music, controlling playback, or enhancing virtual experiences, Soundify delivers a seamless and enjoyable listening experience for users.
