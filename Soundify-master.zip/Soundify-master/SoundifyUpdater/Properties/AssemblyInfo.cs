﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SoundifyUpdater")]
[assembly: AssemblyDescription("Updater for Soundify App")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Scrimmane (Scrim)")]
[assembly: AssemblyProduct("SoundifyUpdater")]
[assembly: AssemblyCopyright("Copyright ©  2024")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("fcce0146-0105-49ac-a9e3-2596fe71ee5a")]
[assembly: AssemblyVersion("6.9.6.9")]
[assembly: AssemblyFileVersion("6.9.6.9")]
